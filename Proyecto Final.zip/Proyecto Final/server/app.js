const express=require('express');
const app=  express();

const mongoose = require('mongoose');
mongoose.connect("mongodb://localhost:27017/VENTA", (err)=>{
    if(!err) console.log('db connected');
    else console.log('db error');

})

const NewSchema = new mongoose.Schema({
    sku: String,
    name: String,
    price: Number
})

const newModel = new mongoose.model("productos", NewSchema);


const data = async()=> {
    const result =await newModel.insertMany([{
        sku: "P1",
        name: "Fresas",
        price: 10
    },
    {   sku: "P2",
        qty:   1 ,
        name: "Uvas",
        price: 9

    },
    {   sku: "P3",
        qty:    2,
        name: "Limón",
        price: 8

    }])
    console.log(result);
}
data();

/*const actualizar = async (id)=>{
    const result = await newModel.updateOne({_id:id},
    {
        $set:{
            sku:"P105",
            qty: 220,
            name: "Puerco AGOTADO",
            price: 20
        }
    })
};

actualizar('639dd33512b219b628ff0164')*/


/*const eliminar= async (id)=>{
    const result = await newModel.deleteOne({_id:id})};
eliminar('639dd33512b219b628ff0161')*/

app.listen(5000,()=>{
    console.log('lola')
});
